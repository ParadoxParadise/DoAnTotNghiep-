import tkinter as tk
from tkinter import ttk, scrolledtext, simpledialog, messagebox
from PIL import Image, ImageTk
import face_recognition
import cv2
import numpy as np
import os
import datetime
import time
import threading
import pickle
import json
import redis

# ===================== CONFIGURATION =====================
HOME_DIR = os.path.expanduser("~")
WAZUH_LOG_FILE = os.path.join(HOME_DIR, "facial_wazuh.log")
UNKNOWN_PHOTO_DIR = os.path.join(HOME_DIR, "unknown_faces")
DATASET_DIR = "dataset"
ENCODINGS_FILE = "encodings.pickle"
AUTHORIZED_FILE = "authorized_users.json"

# Optimization settings
CV_SCALER = 4          # Resize factor for detection (higher = faster but less accurate for small faces)
SKIP_FRAMES = 5        # Process detection every N frames to save CPU
CAMERA_RES = (640, 480) # Lower resolution for better FPS on Pi

# Redis Configuration
REDIS_HOST = 'localhost'
REDIS_PORT = 6379
REDIS_DB = 0
REDIS_KEY = "device:pi5:auth_status"
AUTH_TTL = 5           # Seconds before auth status expires in Redis

# Check for Picamera2
try:
    from picamera2 import Picamera2
    USING_PICAM2 = True
except ImportError:
    USING_PICAM2 = False

# ===================== MAIN APPLICATION =====================
class FaceGuardPro:
    def __init__(self, root):
        self.root = root
        self.root.title("FaceGuard PRO - Redis Integration")
        self.root.geometry("1200x800")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # --- State Variables ---
        self.is_running = False
        self.picam2 = None
        self.cap = None
        self.known_face_encodings = []
        self.known_face_names = []
        self.authorized_users = []
        self.last_log_time = {}
        
        # --- Optimization Variables ---
        self.frame_count = 0
        self.start_time = time.time()
        self.last_face_locations = []
        self.last_face_names = []
        self.last_statuses = []

        # --- Redis Setup ---
        self.redis_client = None
        self.last_redis_update = 0
        self.connect_redis()

        # --- Directory Setup ---
        os.makedirs(UNKNOWN_PHOTO_DIR, exist_ok=True)
        os.makedirs(DATASET_DIR, exist_ok=True)
        if not os.path.exists(WAZUH_LOG_FILE): 
            open(WAZUH_LOG_FILE, 'a').close()
        
        # --- Load Data ---
        self.load_authorized_users()
        self.load_encodings()
        
        # --- Build UI & Start Camera ---
        self.build_gui()
        self.start_camera()

    # ================= REDIS & DATA MANAGEMENT =================
    def connect_redis(self):
        try:
            self.redis_client = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, decode_responses=True)
            self.redis_client.ping()
            print("[REDIS] Connected successfully.")
        except Exception as e:
            print(f"[REDIS] Connection failed: {e}")
            self.redis_client = None

    def sync_to_redis(self, user_name, status):
        if not self.redis_client: return

        now = time.time()
        # Limit Redis updates to avoid network spam (every 1 second)
        if now - self.last_redis_update < 1: 
            return

        try:
            if status == "AUTHORIZED":
                payload = json.dumps({
                    "device": "pi5",
                    "user": user_name,
                    "status": status,
                    "verified_at": datetime.datetime.now().isoformat()
                })
                # Set key with TTL (Time To Live)
                self.redis_client.setex(REDIS_KEY, AUTH_TTL, payload)
            else:
                # If unauthorized or unknown, remove the key immediately
                if self.redis_client.exists(REDIS_KEY):
                    self.redis_client.delete(REDIS_KEY)

            self.last_redis_update = now
        except Exception as e:
            print(f"[REDIS] Error: {e}")

    def load_authorized_users(self):
        if os.path.exists(AUTHORIZED_FILE):
            try:
                with open(AUTHORIZED_FILE, 'r') as f:
                    self.authorized_users = json.load(f)
            except:
                self.authorized_users = []
        else:
            self.authorized_users = []

    def save_authorized_users(self):
        try:
            with open(AUTHORIZED_FILE, 'w') as f:
                json.dump(self.authorized_users, f)
            self.log_gui("Authorized users list saved.", "INFO")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save authorized users: {e}")

    def load_encodings(self):
        self.log_gui("Loading face model...", "INFO")
        try:
            with open(ENCODINGS_FILE, "rb") as f:
                data = pickle.load(f)
            self.known_face_encodings = data["encodings"]
            self.known_face_names = data["names"]
            self.update_status(f"Model Loaded: {len(self.known_face_encodings)} faces")
            self.log_gui(f"Loaded {len(self.known_face_encodings)} faces.", "INFO")
        except FileNotFoundError:
            self.update_status("Model NOT Found. Please Retrain.")
            self.log_gui("encodings.pickle not found.", "WARNING")
        except Exception as e:
            self.log_gui(f"Error loading model: {e}", "ALERT")

    # ================= GUI CONSTRUCTION =================
    def build_gui(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TButton", font=('Helvetica', 10), padding=5)
        style.configure("Big.TButton", font=('Helvetica', 12, 'bold'), padding=10)
        style.configure("Alarm.TLabel", foreground="red", font=('Helvetica', 14, 'bold'))

        # Main Container
        main_container = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left Panel: Video
        left_panel = ttk.LabelFrame(main_container, text="Live Monitoring")
        main_container.add(left_panel, weight=3)
        
        self.video_label = ttk.Label(left_panel, background="black")
        self.video_label.pack(fill=tk.BOTH, expand=True)

        # Right Panel: Controls & Logs
        right_panel = ttk.Frame(main_container)
        main_container.add(right_panel, weight=1)

        # Status Section
        status_frame = ttk.LabelFrame(right_panel, text="System Status")
        status_frame.pack(fill=tk.X, pady=5)
        self.lbl_status = ttk.Label(status_frame, text="IDLE", font=('Helvetica', 12))
        self.lbl_status.pack(pady=5)
        self.lbl_fps = ttk.Label(status_frame, text="FPS: 0.0")
        self.lbl_fps.pack()

        # Controls Section
        control_frame = ttk.LabelFrame(right_panel, text="Controls")
        control_frame.pack(fill=tk.X, pady=10)

        self.btn_toggle = ttk.Button(control_frame, text="▶ START MONITORING", style="Big.TButton", command=self.toggle_monitoring)
        self.btn_toggle.pack(fill=tk.X, padx=5, pady=5)

        ttk.Separator(control_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)

        ttk.Button(control_frame, text="👤 Add New User", command=self.open_add_user).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(control_frame, text="🔑 Manage Access", command=self.open_access_manager).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(control_frame, text="🔄 Retrain Model", command=self.start_retrain_thread).pack(fill=tk.X, padx=5, pady=2)

        # Logs Section
        log_frame = ttk.LabelFrame(right_panel, text="Live Wazuh Logs")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.log_text = scrolledtext.ScrolledText(log_frame, height=10, wrap=tk.WORD, font=('Consolas', 9), bg="#1e1e1e", fg="white")
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.tag_config("INFO", foreground="#00ff00")
        self.log_text.tag_config("WARNING", foreground="yellow")
        self.log_text.tag_config("ALERT", foreground="red", font=('Consolas', 9, 'bold'))

    # ================= HARDWARE CONTROL (STUB) =================
    def control_hardware(self, is_authorized):
        # Add GPIO control logic here (e.g., Relay ON/OFF)
        if is_authorized:
            # print(">> GPIO: OPEN DOOR")
            pass
        else:
            # print(">> GPIO: CLOSE DOOR / ALARM")
            pass

    # ================= CORE LOGIC: PROCESSING =================
    def start_camera(self):
        if USING_PICAM2:
            try:
                self.picam2 = Picamera2()
                # Set low resolution for speed (640x480)
                self.picam2.configure(self.picam2.create_preview_configuration(main={"format": 'XRGB8888', "size": CAMERA_RES}))
                self.picam2.start()
                self.log_gui("Picamera2 started.", "INFO")
            except Exception as e:
                self.log_gui(f"Picamera2 error: {e}. Using OpenCV.", "WARNING")
                self.USING_PICAM2 = False
                self.cap = cv2.VideoCapture(0)
        else:
            self.cap = cv2.VideoCapture(0)
        
        self.update_video_feed()

    def update_video_feed(self):
        frame = self.get_frame()
        if frame is not None:
            # Run detection logic if monitoring is active
            if self.is_running:
                frame = self.process_frame_optimized(frame)
            
            # Display logic
            if not USING_PICAM2:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            img = Image.fromarray(frame)
            img.thumbnail((800, 600))
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)
            
            # FPS Calculation
            self.frame_count += 1
            if self.frame_count % 30 == 0: # Update FPS every 30 frames
                elapsed = time.time() - self.start_time
                if elapsed > 0:
                    self.lbl_fps.config(text=f"FPS: {30 / elapsed:.1f}")
                    self.start_time = time.time()

        self.root.after(10, self.update_video_feed)

    def process_frame_optimized(self, frame):
        display_frame = frame.copy()
        
        # === OPTIMIZATION: Skip frames to save CPU ===
        if self.frame_count % SKIP_FRAMES == 0:
            # 1. Resize for faster detection
            small_frame = cv2.resize(frame, (0, 0), fx=1/CV_SCALER, fy=1/CV_SCALER)
            
            if not USING_PICAM2:
                rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
            else:
                rgb_small_frame = small_frame

            # 2. Detect faces
            self.last_face_locations = face_recognition.face_locations(rgb_small_frame, model="hog")
            face_encodings = face_recognition.face_encodings(rgb_small_frame, self.last_face_locations)

            self.last_face_names = []
            self.last_statuses = []
            
            any_authorized_detected = False

            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(self.known_face_encodings, face_encoding, tolerance=0.5)
                name = "Unknown"
                face_distances = face_recognition.face_distance(self.known_face_encodings, face_encoding)
                
                if len(face_distances) > 0:
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        name = self.known_face_names[best_match_index]
                
                self.last_face_names.append(name)
                
                # Check Authorization
                is_authorized = name in self.authorized_users
                self.last_statuses.append(is_authorized)

                if is_authorized:
                    any_authorized_detected = True
                    self.sync_to_redis(name, "AUTHORIZED")
                    self.control_hardware(True)
                    
                    # Log throttling
                    if time.time() - self.last_log_time.get(name, 0) > 10:
                        self.log_wazuh(f"Authorized access: {name}", "INFO")
                        self.last_log_time[name] = time.time()
                else:
                    self.sync_to_redis(name, "UNAUTHORIZED")
                    self.control_hardware(False)
                    
                    # Log throttling for unauthorized
                    if time.time() - self.last_log_time.get(name, 0) > 10:
                        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                        filename = f"unknown_{ts}.jpg"
                        save_frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR) if USING_PICAM2 else frame
                        cv2.imwrite(os.path.join(UNKNOWN_PHOTO_DIR, filename), save_frame)
                        self.log_wazuh(f"UNAUTHORIZED: {name}! Photo saved.", "ALERT")
                        self.last_log_time[name] = time.time()

            if not self.last_face_names:
                 # No faces detected, maybe clear Redis or let it expire
                 pass

        # === DRAWING RESULTS (Uses cached data for skipped frames) ===
        for (top, right, bottom, left), name, is_auth in zip(self.last_face_locations, self.last_face_names, self.last_statuses):
            # Scale back up
            top *= CV_SCALER
            right *= CV_SCALER
            bottom *= CV_SCALER
            left *= CV_SCALER

            color = (0, 255, 0) if is_auth else (255, 0, 0)
            if not USING_PICAM2: color = (color[2], color[1], color[0]) # Fix BGR for OpenCV

            cv2.rectangle(display_frame, (left, top), (right, bottom), color, 2)
            cv2.putText(display_frame, name.upper(), (left, top - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        return display_frame

    def get_frame(self):
        try:
            if USING_PICAM2 and self.picam2:
                return self.picam2.capture_array()
            elif self.cap:
                ret, frame = self.cap.read()
                if ret: return frame
        except:
            pass
        return None

    # ================= FEATURES =================
    def toggle_monitoring(self):
        self.is_running = not self.is_running
        if self.is_running:
            if not self.known_face_encodings:
                messagebox.showwarning("Warning", "No model loaded. Please Retrain first.")
                self.is_running = False; return
            self.btn_toggle.config(text="⏹ STOP MONITORING", style="Alarm.TLabel")
            self.update_status("MONITORING ACTIVE")
            self.log_wazuh("System ARMED.", "INFO")
        else:
            self.btn_toggle.config(text="▶ START MONITORING", style="Big.TButton")
            self.update_status("MONITORING PAUSED")
            self.log_wazuh("System DISARMED.", "INFO")

    def open_add_user(self):
        name = simpledialog.askstring("New User", "Enter user name (e.g., 'john_doe'):")
        if not name: return
        user_dir = os.path.join(DATASET_DIR, name.lower().replace(" ", "_"))
        os.makedirs(user_dir, exist_ok=True)
        
        cap_win = tk.Toplevel(self.root)
        cap_win.title(f"Capturing: {name}")
        lbl_info = ttk.Label(cap_win, text=f"Taking photos for {name}. Move your head slowly.")
        lbl_info.pack(pady=10)
        
        count = 0
        def take_photo():
            nonlocal count
            frame = self.get_frame()
            if frame is not None:
                ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                path = os.path.join(user_dir, f"{ts}.jpg")
                save_img = frame if USING_PICAM2 else cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                cv2.imwrite(path, save_img)
                count += 1
                lbl_info.config(text=f"Captured: {count} photos")
        
        ttk.Button(cap_win, text="📸 SNAPSHOT", command=take_photo, style="Big.TButton").pack(pady=20, padx=50)

    def open_access_manager(self):
        mgr_win = tk.Toplevel(self.root)
        mgr_win.title("Access Control Manager")
        mgr_win.geometry("600x400")
        mgr_win.grab_set()

        all_users = sorted(list(set(self.known_face_names)))
        pane = ttk.PanedWindow(mgr_win, orient=tk.HORIZONTAL)
        pane.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left: All Users
        frame_all = ttk.LabelFrame(pane, text="All Detected Users")
        pane.add(frame_all, weight=1)
        list_all = tk.Listbox(frame_all, selectmode=tk.MULTIPLE)
        list_all.pack(fill=tk.BOTH, expand=True)

        # Middle: Buttons
        frame_btns = ttk.Frame(pane)
        pane.add(frame_btns, weight=0)
        
        def authorize_selected():
            selected = [list_all.get(i) for i in list_all.curselection()]
            for user in selected:
                if user not in self.authorized_users:
                    self.authorized_users.append(user)
            refresh_lists()
            self.save_authorized_users()

        def revoke_selected():
            selected = [list_auth.get(i) for i in list_auth.curselection()]
            for user in selected:
                if user in self.authorized_users:
                    self.authorized_users.remove(user)
            refresh_lists()
            self.save_authorized